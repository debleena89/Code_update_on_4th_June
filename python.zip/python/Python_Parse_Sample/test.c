int func(int x) {    
  int result = (x / 42);
  return result;
}

int main()
{
  int result = func(84);
   
}
