void foo()
{
    int a = 0, b = 0;
    printf("Hi");
    a++;
    printf("Hi");
    if(a<5)
   {
         b++;
         printf("Hi"); 
    }
    printf("Hi");
    b--;
    printf("Hi");
}
