
def parse_formula(to_parse):
    print(to_parse)
    string = ['p1','p2','Xp1','(Xp1)Up2']
    print(string)

if __name__ == "__main__":

#------The two matrices are assigned values----------------
    print("Trying to achieve LTL to Buchi conversion")
    parse_string = '(Xp1)Up2'
    parse_formula(parse_string)
    

    
    
    
    
