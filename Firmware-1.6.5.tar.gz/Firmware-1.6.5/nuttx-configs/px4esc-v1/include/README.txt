This directory contains header files unique to the
PX4 Esc V1.6 board using STM32F446RET6
