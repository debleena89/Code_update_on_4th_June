Further examples are available in

/examples/ccs15/

which are also symlinked here.
